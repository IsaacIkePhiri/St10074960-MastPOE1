import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const BookListScreen: React.FC = () => {
  // Sample list of books (you can replace this with your actual data)
  const books = [
    { title: 'Book 1', author: 'Author 1', genre: 'Fiction', pages: 200 },
    { title: 'Book 2', author: 'Author 2', genre: 'Non-Fiction', pages: 300 },
    { title: 'Book 3', author: 'Author 3', genre: 'Mystery', pages: 250 },
    // Add more books as needed
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Book List</Text>

      <FlatList
        data={books}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.bookItem}>
            <Text>Title: {item.title}</Text>
            <Text>Author: {item.author}</Text>
            <Text>Genre: {item.genre}</Text>
            <Text>Pages: {item.pages}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  bookItem: {
    marginVertical: 10,
    padding: 10,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
  },
});

export default BookListScreen;
