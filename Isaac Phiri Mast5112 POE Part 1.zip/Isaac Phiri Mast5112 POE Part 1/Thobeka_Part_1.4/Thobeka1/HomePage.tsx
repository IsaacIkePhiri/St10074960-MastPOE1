// src/HomePage.tsx
import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const HomePage: React.FC = () => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [genre, setGenre] = useState('Fiction'); // Default genre
  const [pages, setPages] = useState('');

  const genres = ['Fiction', 'Non-Fiction', 'Mystery', 'Science Fiction', 'Fantasy'];

  const handleSave = () => {
    // Handle saving the book details (e.g., send to an API, store in local storage)
    console.log('Book Details:', { title, author, genre, pages });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Book Details</Text>

      <TextInput
        style={styles.input}
        placeholder="Title"
        value={title}
        onChangeText={(text) => setTitle(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Author"
        value={author}
        onChangeText={(text) => setAuthor(text)}
      />

      <Text style={styles.label}>Genre</Text>
      <View style={styles.genreContainer}>
        {genres.map((item) => (
          <View key={item} style={styles.genreOption}>
            <Text
              style={[
                styles.genreText,
                { backgroundColor: item === genre ? '#3498db' : '#e0e0e0' },
              ]}
              onPress={() => setGenre(item)}>
              {item}
            </Text>
          </View>
        ))}
      </View>

      <TextInput
        style={styles.input}
        placeholder="Number of Pages"
        value={pages}
        onChangeText={(text) => setPages(text)}
        keyboardType="numeric"
      />

      <Button title="Save" onPress={handleSave} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginTop: 10,
    paddingHorizontal: 10,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
  },
  genreContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginTop: 10,
  },
  genreOption: {
    margin: 5,
  },
  genreText: {
    fontSize: 16,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
    color: '#ffffff',
    textAlign: 'center',
  },
});

export default HomePage;